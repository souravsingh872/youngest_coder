import 'package:flutter/material.dart';

const activeCardColur = Color(0xFF1D1E33);
const botomContainerColor=Color(0xFFEB1555);
const inActiveColor = Color(0xFF111328);
const textstyle = TextStyle(fontSize: 18,color: Color(0xFF8D8E98));
const numberStyle = TextStyle(fontSize: 50, fontWeight: FontWeight.w900);
const largetextStyle = TextStyle(fontSize: 25, fontWeight: FontWeight.w900,color: Colors.white);
const resulttextStyle = TextStyle(fontSize: 50, fontWeight: FontWeight.w900,color: Colors.white);
const normaltextStyle = TextStyle(fontSize: 18,color: Colors.green);
const bmitextStyle = TextStyle(fontSize: 100, fontWeight: FontWeight.w900,color: Colors.white);
const yourtextstyle = TextStyle(fontSize: 22,color: Colors.white);