import 'dart:math';
enum Gender { male, female }
class BmiBrain{
  final int? height;
  final int? weight;
  final int? age;
  final String? gender;


  BmiBrain({this.height, this.weight, this.age,this.gender});

  double _bmi = 0;

  String calculateBmi() {
     _bmi =weight! / pow(height!/100, 2);
    return _bmi.toStringAsFixed(1);
}

   String getResult(){
    if(_bmi >= 25){
      return  "OverWeight";
    }
    else if (_bmi > 18.5){
      return "Normal";
    }
    else{
      return "UnderWeight";
    }
   }

   String getInterpretation(){
     if(_bmi >= 25){
       return  "You have heigher than your body weight. Try to exercise more";
     }
     else if (_bmi > 18.5){
       return "You have normal body weight";
     }
     else{
       return "Your Bmi result is quite low you shold eat more!";
     }
   }
   String ageCalculation(){
    if(age! >= 45){
      return "Tum Budhe HO!";
    }else if(age! >=21 && age!<45){
      return "tum abhi jawan ho";
    }
    else if(Gender.male == gender ){
      return "tum nibba ho";
    }
    else{
      return "tum nibbi ho";
    }

   }



}